package com.example.fitnessapp.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.fitnessapp.R;
import com.example.fitnessapp.adapters.MealAdapter;
import com.example.fitnessapp.models.Meal;
import java.util.ArrayList;
import java.util.List;

public class DietActivity extends AppCompatActivity {

    private EditText mealNameEditText;
    private EditText mealCaloriesEditText;
    private Button addMealButton;
    private RecyclerView mealsRecyclerView;
    private MealAdapter mealAdapter;
    private List<Meal> mealList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diet);

        mealNameEditText = findViewById(R.id.edit_meal_name);
        mealCaloriesEditText = findViewById(R.id.edit_meal_calories);
        addMealButton = findViewById(R.id.button_add_meal);
        mealsRecyclerView = findViewById(R.id.recycler_view_meals);

        mealList = new ArrayList<>();
        mealAdapter = new MealAdapter(mealList);
        mealsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mealsRecyclerView.setAdapter(mealAdapter);

        addMealButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addMeal();
            }
        });
    }

    private void addMeal() {
        String mealName = mealNameEditText.getText().toString().trim();
        String mealCaloriesString = mealCaloriesEditText.getText().toString().trim();

        if (!TextUtils.isEmpty(mealName) && !TextUtils.isEmpty(mealCaloriesString)) {
            int mealCalories = Integer.parseInt(mealCaloriesString);
            Meal meal = new Meal(mealName, mealCalories);
            mealList.add(meal);
            mealAdapter.notifyItemInserted(mealList.size() - 1);
            mealNameEditText.setText("");
            mealCaloriesEditText.setText("");
        }
    }
}
