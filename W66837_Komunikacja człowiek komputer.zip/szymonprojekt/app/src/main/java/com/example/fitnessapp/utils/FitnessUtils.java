package com.example.fitnessapp.utils;

public class FitnessUtils {
    // Utility methods for fitness calculations
    public static double calculateCaloriesBurned(int steps) {
        // Simplified formula: 0.04 calories per step
        return steps * 0.04;
    }
}