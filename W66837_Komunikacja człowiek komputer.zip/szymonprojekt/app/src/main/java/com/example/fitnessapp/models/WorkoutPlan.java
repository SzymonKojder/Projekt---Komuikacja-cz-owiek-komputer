package com.example.fitnessapp.models;

import java.util.List;

public class WorkoutPlan {
    private String name;
    private List<String> exercises;

    public WorkoutPlan(String name, List<String> exercises) {
        this.name = name;
        this.exercises = exercises;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getExercises() {
        return exercises;
    }

    public void setExercises(List<String> exercises) {
        this.exercises = exercises;
    }
}
