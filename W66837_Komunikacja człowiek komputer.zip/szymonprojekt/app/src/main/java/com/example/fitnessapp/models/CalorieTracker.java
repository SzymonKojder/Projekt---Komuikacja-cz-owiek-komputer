package com.example.fitnessapp.models;

public class CalorieTracker {
    private int caloriesBurned;

    public CalorieTracker() {
        this.caloriesBurned = 0;
    }

    public int getCaloriesBurned() {
        return caloriesBurned;
    }

    public void setCaloriesBurned(int caloriesBurned) {
        this.caloriesBurned = caloriesBurned;
    }

    public void addCalories(int calories) {
        this.caloriesBurned += calories;
    }
}
