package com.example.fitnessapp.models;

public class StepTracker {
    private int steps;
    private double distance;

    public StepTracker() {
        this.steps = 0;
        this.distance = 0.0;
    }

    public int getSteps() {
        return steps;
    }

    public void setSteps(int steps) {
        this.steps = steps;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public void addSteps(int steps) {
        this.steps += steps;
        // Assume each step is 0.8 meters
        this.distance += steps * 0.8 / 1000;
    }
}
